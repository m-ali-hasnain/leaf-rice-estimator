import {
  Avatar,
  Button,
  Card,
  Title,
  Paragraph,
  Badge,
} from 'react-native-paper';
import { View } from 'react-native';
import React from 'react';
import { auth } from '../../firebase';
import axios from 'axios';
import { API_URL } from '@env';

/* Defingin Card Properties here */

const LeftContent = (props) => (
  <Avatar.Image
    {...props}
    size={40}
    source={require('../../Image/aboutreact.png')}
  />
);

const CustomCard = ({
  short_rice_count,
  long_rice_count,
  avg_length,
  avg_width,
  image,
  setPhoto,
}) => {
  const [isSaved, setIsSaved] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const handleSave = async (e) => {
    // Save to firebase
    e.preventDefault();
    try {
      setLoading(true);
      let data = {
        short_rice_count,
        long_rice_count,
        avg_length,
        avg_width,
        healthy: avg_length > 4.5 ? true : false,
        userId: auth.currentUser.uid,
        imageUrl: image,
      };
      const response = await axios.post(`${API_URL}/api/v1/create/`, data);
      if (response.data.success) {
        setIsSaved(true);
        setLoading(false);
      }
    } catch (e) {
      console.error('Error adding document: ', e);
      setLoading(false);
    }
  };
  return (
    <Card
      mode="elevated"
      style={{
        width: '90%', // adjust the width to ensure it fits within the view
        maxWidth: 400,
      }}
    >
      <Card.Title
        title="Rice Detector"
        subtitle={loading ? 'Saving Data...' : isSaved && 'Saved Successfully'}
        left={LeftContent}
      />

      <Card.Content style={{ marginBottom: 8 }}>
        <View
          style={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}
        >
          <Title>Summary</Title>

          <Badge
            style={{
              backgroundColor: avg_length > 4.5 ? '	#198754' : '#DC3545',
              color: '#FFF',
            }}
            size={20}
          >
            {avg_length === undefined
              ? 'None'
              : avg_length > 4.5
              ? 'Healthy'
              : 'Unhealthy'}
          </Badge>
        </View>
        <Paragraph>Total Short Rice: {short_rice_count || 0}</Paragraph>
        <Paragraph>Total Long Rice: {long_rice_count || 0}</Paragraph>
        <Paragraph>Average Length: {avg_length?.toFixed(2) || 0.0}</Paragraph>
        <Paragraph>Average Width: {avg_width?.toFixed(2) || 0.0}</Paragraph>
      </Card.Content>
      <Card.Cover source={{ uri: image || 'https://picsum.photos/700' }} />
      <Card.Actions>
        <Button onPress={handleSave} disabled={isSaved}>
          Save
        </Button>
        <Button
          onPress={() => {
            console.log(process.env.API_URL);
            setPhoto(undefined);
          }}
        >
          Cancel
        </Button>
      </Card.Actions>
    </Card>
  );
};

export default CustomCard;
