import React from 'react';
import axios from 'axios';
import { StatusBar } from 'expo-status-bar';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  Image,
  Pressable,
  Button,
} from 'react-native';
import { useEffect, useRef, useState } from 'react';
import { Camera } from 'expo-camera';
import { shareAsync } from 'expo-sharing';
import * as MediaLibrary from 'expo-media-library';
import { API_URL } from '@env';

import CustomCard from '../Components/CustomCard';

const RiceScreen = () => {
  let cameraRef = useRef();
  const [hasCameraPermission, setHasCameraPermission] = useState();
  const [hasMediaLibraryPermission, setHasMediaLibraryPermission] = useState();
  const [photo, setPhoto] = useState();
  const [response, setResponse] = useState(null); // For response that comes from python api
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const cameraPermission = await Camera.requestCameraPermissionsAsync();
      const mediaLibraryPermission =
        await MediaLibrary.requestPermissionsAsync();
      setHasCameraPermission(cameraPermission.status === 'granted');
      setHasMediaLibraryPermission(mediaLibraryPermission.status === 'granted');
    })();
  }, []);

  if (hasCameraPermission === undefined) {
    return <Text>Requesting permissions...</Text>;
  } else if (!hasCameraPermission) {
    return (
      <Text>
        Permission for camera not granted. Please change this in settings.
      </Text>
    );
  }

  let takePic = async () => {
    let options = {
      quality: 1,
      base64: true,
      exif: false,
    };

    let newPhoto = await cameraRef.current.takePictureAsync(options);
    console.log('new Photo-=====');

    setPhoto(newPhoto);
  };

  if (photo && !loading) {
    let sharePic = () => {
      shareAsync(photo.uri).then(() => {
        setPhoto(undefined);
      });
    };

    let savePhoto = () => {
      MediaLibrary.saveToLibraryAsync(photo.uri).then(() => {
        /*
        Here we will call our django api for image detection
        */
        const data = {
          image: {
            data: photo.base64,
            name: 'rice.jpg',
          },
        };
        // Setting State
        setLoading(true);

        // Calling Api
        axios
          .post(`${API_URL}/api/v1/upload_image/`, data)
          .then((res) => {
            setResponse(res.data);
            setPhoto(undefined);
            setLoading(false);
          })
          .catch((err) => {
            setLoading(false);
            console.log(err);
          });
      });
    };

    return (
      <SafeAreaView style={styles.container}>
        <Image
          style={styles.preview}
          source={{ uri: 'data:image/jpg;base64,' + photo.base64 }}
        />
        <View style={styles.btnStyles}>
          <Button title="Share" onPress={sharePic} style={styles.btn} />
          {hasMediaLibraryPermission ? (
            <Button title="Save" onPress={savePhoto} style={styles.btn} />
          ) : undefined}
          <Button
            title="Discard"
            onPress={() => setPhoto(undefined)}
            style={styles.btn}
          />
        </View>
      </SafeAreaView>
    );
  }

  if (loading) {
    return <Text>Scanning...</Text>;
  }

  return (
    <>
      {/* If response state is not null, that means python api sends response
        and we will display our report
       */}
      {response !== null ? (
        <View style={styles.cardContainer}>
          <CustomCard
            long_rice_count={response?.data.long_rice_count}
            short_rice_count={response?.data.short_rice_count}
            avg_length={response?.data?.avg_length}
            avg_width={response?.data?.avg_width}
            image={response?.image}
            setPhoto={setPhoto}
          />
        </View>
      ) : (
        <Camera style={styles.container} ref={cameraRef}>
          <View style={styles.buttonContainer}>
            <Pressable onPress={takePic} style={styles.circleBtn}>
              <View></View>
            </Pressable>
          </View>
          <StatusBar style="auto" />
        </Camera>
      )}
    </>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardContainer: {
    height: '100%',
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 40,
    backgroundColor: '#fff',
    borderRadius: 50,
  },
  preview: {
    alignSelf: 'stretch',
    flex: 1,
  },
  circleBtn: {
    height: 100,
    width: 100,
    borderRadius: 100,
    backgroundColor: 'black',
    borderColor: 'red',
    borderWidth: 5,
  },
  btnStyles: {
    width: '100%',
    backgroundColor: '#1df289',
    paddingHorizontal: 50,
    paddingVertical: 10,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  Btn: {},
});

export default RiceScreen;
