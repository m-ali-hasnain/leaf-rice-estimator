import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import {
  DataTable,
  Modal,
  Portal,
  Provider,
  Card,
  Avatar,
  Title,
  Badge,
  Paragraph,
} from 'react-native-paper';
import axios from 'axios';
import { auth } from '../../firebase/';
import { API_URL } from '@env';

const ReportsScreen = ({ navigation }) => {
  const [riceData, setRiceData] = React.useState([]);
  const [visible, setVisible] = React.useState(false);
  const [row, setRow] = React.useState();

  const LeftContent = (props) => (
    <Avatar.Image
      {...props}
      size={40}
      source={require('../../Image/aboutreact.png')}
    />
  );
  // Functions
  const hideModal = () => {
    setVisible(false);
    setRow(null);
  };

  // This function fetches reports
  const fetchReports = () => {
    axios
      .get(`${API_URL}/api/v1?user_id=${auth.currentUser.uid}`)
      .then((res) => {
        setRiceData(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // This useEffect fetches Report Data
  useEffect(() => {
    fetchReports();
  }, []);

  const handleClick = (row) => {
    setRow(row);
    setVisible(true);
  };
  return (
    <View
      style={{
        backgroundColor: '#FFF',
        flex: 1,
      }}
    >
      <View
        style={{
          backgroundColor: '#00a46c',
          height: '18%',
          justifyContent: 'center',
          alignItems: 'center',
          padding: 20,
        }}
      >
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: 25,
            width: '100%',
          }}
        >
          <View style={{ width: '100%' }}>
            <Text
              style={{
                fontSize: 28,
                color: '#FFF',
                fontWeight: 'bold',
              }}
            >
              Reports
            </Text>
          </View>
        </View>
      </View>

      {/* Modal here */}
      {visible ? (
        <Provider>
          <Portal>
            <Modal
              visible={visible}
              onDismiss={hideModal}
              contentContainerStyle={styles.containerStyle}
            >
              <Card
                mode="elevated"
                style={{
                  width: '100%', // adjust the width to ensure it fits within the view
                  maxWidth: 400,
                }}
              >
                <Card.Title title="Rice Detector Report" left={LeftContent} />

                <Card.Content style={{ marginBottom: 8 }}>
                  <View
                    style={{
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}
                  >
                    <Title>Summary</Title>

                    <Badge
                      style={{
                        backgroundColor:
                          row.avg_length > 4.5 ? '	#198754' : '#DC3545',
                        color: '#FFF',
                      }}
                      size={20}
                    >
                      {row.avg_length === undefined
                        ? 'None'
                        : row.avg_length > 4.5
                        ? 'Healthy'
                        : 'Unhealthy'}
                    </Badge>
                  </View>
                  <Paragraph>
                    Total Short Rice: {row.short_rice_count || 0}
                  </Paragraph>
                  <Paragraph>
                    Total Long Rice: {row.long_rice_count || 0}
                  </Paragraph>
                  <Paragraph>
                    Average Length: {row.avg_length?.toFixed(2) || 0.0}
                  </Paragraph>
                  <Paragraph>
                    Average Width: {row.avg_width?.toFixed(2) || 0.0}
                  </Paragraph>
                </Card.Content>
                <Card.Cover
                  source={{ uri: row.imageUrl || 'https://picsum.photos/700' }}
                />
              </Card>
            </Modal>
          </Portal>
        </Provider>
      ) : (
        <DataTable>
          <DataTable.Header>
            <DataTable.Title style={styles.inCenter}>User Id</DataTable.Title>
            <DataTable.Title style={styles.inCenter}>Image</DataTable.Title>
            <DataTable.Title style={styles.inCenter}>Healthy</DataTable.Title>
          </DataTable.Header>

          {riceData.map((item, index) => (
            <DataTable.Row
              item={index}
              height={100}
              onPress={() => handleClick(item)}
            >
              <DataTable.Cell style={styles.inCenter}>
                {item.userId}
              </DataTable.Cell>
              <DataTable.Cell style={styles.inCenter}>
                <Image
                  source={{ uri: item.imageUrl || 'https://picsum.photos/700' }}
                  style={{ width: 50, height: 50 }}
                />
              </DataTable.Cell>
              <DataTable.Cell style={styles.inCenter}>
                {item.healthy ? 'Healthy' : 'Unhealthy'}
              </DataTable.Cell>
            </DataTable.Row>
          ))}

          <DataTable.Pagination
            page={1}
            numberOfPages={3}
            onPageChange={(page) => {
              console.log(page);
            }}
            label={`1-3 of ${riceData.length}`}
          />
        </DataTable>
      )}

      {/* We will display table here for reports */}
    </View>
  );
};
const styles = StyleSheet.create({
  inCenter: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  containerStyle: {
    backgroundColor: 'white',
  },
});

export default ReportsScreen;
