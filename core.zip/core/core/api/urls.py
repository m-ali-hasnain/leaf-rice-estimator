from django.urls import path, include
from home.views import *

urlpatterns = [
    path('create/', create),
    path('upload_image/', upload_image),
    path('', index),
]
