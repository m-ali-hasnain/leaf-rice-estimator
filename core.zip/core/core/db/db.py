import pyrebase

config = {
    "apiKey": "",
    "authDomain": "",
    "projectId": "",
    "storageBucket": "",
    "messagingSenderId": "",
    "appId": "",
    "measurementId": "",
    'databaseURL': ""
}


# This function returns firebase instance
def get_connection():
    firebase = pyrebase.initialize_app(config)
    return firebase.database()
