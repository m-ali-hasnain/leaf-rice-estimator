import base64
from rest_framework.decorators import api_view
from rest_framework.response import Response
from utils.utils import get_unique_file_name, save_image
from services.object_detector import HomogeneousBgDetector
from services.cloudinary import upload
from db.db import get_connection
import io
from rest_framework.parsers import JSONParser
from constants.constants import TEMP_DIR


firebase = get_connection()


# This view is responsible for retrieving data from firebase
@api_view(['GET', 'POST', 'PUT', 'PATCH', 'DELETE'])
def index(request):
    user_id = request.GET.get('user_id', None)
    if user_id is not None:
        print(user_id)
        records = firebase.child(
            "rice-data").order_by_child("userId").equal_to(user_id).get()

        json_records = []
        for record in records.each():
            json_records.append(record.val())

        return Response({'success': True, 'data': json_records})

    data = {
        'success': True,
        'message': 'Please provide user id in params',

    }
    return Response(data)


# This view is responsible for image detection and uploading image to cloudinary
@api_view(['POST', 'GET'])
def upload_image(request):

    try:
        if request.method == 'POST':
            if request.FILES and 'image' in request.FILES.keys():
                file = request.FILES['image']
                image_name = get_unique_file_name(file.name)
            else:
                image_name = request.data['image']['name']
                image_b64_data = request.data['image']['data']

            # Saving image
            file_path = TEMP_DIR / image_name
            save_image(file_path, base64.b64decode(image_b64_data), b64=True) if image_b64_data else save_image(
                file_path, file.chunks())

            # Now we will detect image using detector
            detector = HomogeneousBgDetector()
            image_data = detector.detect(image_name)

            # """
            #     Finally we read stream from detected image
            #     Convert it to base64 format and return in response
            #     """
            # detected_image_path = TEMP_DIR / \
            #     f"{image_name.split('.')[0]}_detected.{image_name.split('.')[1]}"
            # detected_image = None
            # with open(detected_image_path, 'rb') as f:
            #     detected_image = base64.b64encode(f.read())

            # Now we will upload detected image to the cloudinary
            detected_image_path = TEMP_DIR / \
                f"{image_name.split('.')[0]}_detected.{image_name.split('.')[1]}"

            url = upload(detected_image_path)

            return Response({'success': True,
                            'message': 'Image has been saved successfully.',
                             'data': image_data,
                             'image': url})

        else:
            return Response(dummy_response())

    except KeyError as e:
        return Response({'success': False, 'message': f" {str(e)} is not found in request data. "})

    except Exception as e:
        return Response({'success': False, 'message': f" Request is not completed due to following error:\n{str(e)}"})


# This view is responsible for storing data in firebase
@api_view(['POST'])
def create(request):
    try:
        data = request.body
        if data is not None or data.get('userId') is not None:
            data = io.BytesIO(data)
            data = JSONParser().parse(data)
            print(data)
            firebase.child("rice-data").push(data)
            return Response({'success': True, 'message': 'Stored Successfully'})
        else:
            return Response({'success': False, 'message': 'Missing Body'})
    except Exception as e:
        print(e)
        return Response({'success': False, 'message': f" Request is not completed due to following error:\n{str(e)}"})


def dummy_response():
    return {"success": True,
            "message": "Image has been saved successfully.",
            "data": {
                "short_rice_data": [
                    {
                        "length": 2.540798804957243,
                        "width": 1.9945270618914357
                    },
                    {
                        "length": 4.354436700033762,
                        "width": 3.418232809526504
                    },
                    {
                        "length": 4.163855432857723,
                        "width": 3.268626514793313
                    },
                    {
                        "length": 3.254277796344444,
                        "width": 2.5546080701303886
                    }
                ],
                "long_rice_data": [
                    {
                        "length": 5.468689750451655,
                        "width": 4.2929214541045475
                    },
                    {
                        "length": 5.330100459192836,
                        "width": 4.184128860466377
                    },
                    {
                        "length": 5.536683657885704,
                        "width": 4.346296671440278
                    },
                    {
                        "length": 5.614028096904365,
                        "width": 4.407012056069927
                    },
                    {
                        "length": 4.766056409794648,
                        "width": 3.7413542816887997
                    },
                    {
                        "length": 4.591207223569529,
                        "width": 3.60409767050208
                    },
                    {
                        "length": 4.588443932784409,
                        "width": 3.60192848723576
                    },
                    {
                        "length": 5.242528993351132,
                        "width": 4.115385259780639
                    },
                    {
                        "length": 4.871338165164015,
                        "width": 3.824000459653751
                    },
                    {
                        "length": 4.824245713193516,
                        "width": 3.787032884856911
                    },
                    {
                        "length": 4.937283633576591,
                        "width": 3.8757676523576245
                    },
                    {
                        "length": 5.762304529901316,
                        "width": 4.523409055972532
                    }
                ],
                "short_rice_count": 4,
                "long_rice_count": 12,
                "avg_length": 4.74039245624768,
                "avg_width": 3.7212080781544294
            },
            "image": "https://res.cloudinary.com/dtcb8jjq0/image/upload/v1679425067/rbagcx9axamttbvfajpw.jpg"}
